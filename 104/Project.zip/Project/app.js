console.log(`App`);
//object literal - static information that I will use later on website or project
    // const person={
    //     userName:`Kevin`,
    //     city:`Lisbon`,
    //     age:28,
    //     student: true,
    //     music:[
    //         `Coldplay`,
    //         `Oasis`,
    //         `The Beatles`
    //     ],
    //     address:{
    //         street:`Lazy Willow`,
    //         number:`202`
    //     }
    // }
    // console.log(person.userName);
    // console.log(person.age);
    // console.log(person.music[2]);
    // console.log(person.address.street)

var salon={
    name:`The Fashion Pet`,
    phone:`555-555-5555`,
    address:{
        street:`Palm`,
        number:`345`,
        city:`Orlando`
    },
    hour:{
        open:`9:00am`,
        close:`5:00pm`
    },
    pets:[
        {
            name:`Scooby`,
            age:60,
            gender:`male`,
            breed:`Dane`,
            service:`Full Service`,
            ownerName:`Shaggy`,
            contactPhone:`777-777-7777`
        },
        {
            name:`Scrappy`,
            age:50,
            gender:`male`,
            breed:`Dane`,
            service:`Nails Cut`,
            ownerName:`Shaggy`,
            contactPhone:`777-777-7777`
        },
        {
            name:`Tom`,
            age:91,
            gender:`male`,
            breed:`Cat`,
            service:`Claw Sharpening`,
            ownerName:`Tom's Mom`,
            contactPhone:`888-888-8888`
        },
        {
            name:`Jerry`,
            age:92,
            gender:`male`,
            breed:`Mouse`,
            service:`Whisker Trim`,
            ownerName:`Self Owned`,
            contactPhone:`999-999-9999`
        }
    ]
}
console.log(`${salon.name} opens from ${salon.hour.open} to ${salon.hour.close}.`);

function displayInfo(){
    document.getElementById(`footer-site`).innerHTML=`
    <p>${salon.name}</p>
    <p>${salon.address.number} ${salon.address.street}, ${salon.address.city} | Contact: ${salon.phone}</p>
    <p>The salon is open from ${salon.hour.open} to ${salon.hour.close}
`;
}
displayInfo()

console.log(salon.pets.length)
for(var i=0;i<salon.pets.length;i++){
    console.log(salon.pets[i].name)
    document.getElementById(`table-body`).innerHTML+=`
    <tr>
        <th scope="row">${i+1}</th>
        <td>${salon.pets[i].name}</td>
        <td>${salon.pets[i].ownerName}</td>
        <td>${salon.pets[i].breed}</td>
    </tr>`
}
document.getElementById(`table-caption`).innerHTML+=`${salon.name} currently has ${salon.pets.length} pets registered`

