// Universal Variable
var users = [];

function register(){
    let email = $(`#emailInput`).val();
        password = $(`#passwordInput`).val();
        firstName = $(`#firstNameInput`).val();
        lastName = $(`#lastNameInput`).val();
        dob = $(`#dobInput`).val();
        address = $(`#addressInput`).val();
        phone = $(`#phoneInput`).val();
        payment = $(`input:radio[name=payment]:checked`).val();
        color = $(`#colorInput`).val();

        newUser = new User(email,password,firstName,lastName,dob,address,phone,payment,color);
        console.log(newUser);

        users.push(newUser);
}

class User{
    constructor(email,password,firstName,lastName,dob,address,phone,payment,color){
        this.email=email;
        this.password=password;
        this.firstName=firstName;
        this.lastName=lastName;
        this.dob=dob;
        this.address=address;
        this.phone=phone;
        this.payment=payment;
        this.color=color;
    }
}

function init(){
    $(`#submitBtn`).on(`click`,register);
}

window.onload=init;